let $menu = $(".nav-toggle");
let $nav = $(".nav");
let $navclose = $(".nav-close")
$menu.click(abre);
$navclose.click(abre);

function abre(e) {
    e.preventDefault();
    $nav.toggleClass('active');
}
// fixar header
$(window).scroll(fixar);

function fixar() {
    if ($(this).scrollTop() > 100) {
        $(".header").addClass('fixed');
    } else {
        $(".header").removeClass('fixed');
    }

}
// Array de Imagens
nomesDasImagens = [
    'images/github.png',
    'images/baresicon.png',
    'images/close.png',
];
let $botao_anterior = $("#anterior");
let $botao_proximo = $("#proximo");
let cont = 0;

$botao_anterior.click(anterior);
$botao_proximo.click(proximo);

function proximo() {
    let $img = $("#imagem");
    cont++;
    if (cont > 2) {
        cont = 0;
        $img.attr('src', nomesDasImagens[cont]);
    } else {
        $img.attr('src', nomesDasImagens[cont]);
    }
}

function anterior() {
    let $img = $("#imagem");
    cont--;
    if (cont < 0) {
        cont = 2;
        $img.attr('src', nomesDasImagens[cont]);
    } else {
        $img.attr('src', nomesDasImagens[cont]);
    }
}