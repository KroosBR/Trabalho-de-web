let $menu = $(".nav-toggle");
let $nav = $(".nav");
let $navclose = $(".nav-close")
$menu.click(abre);
$navclose.click(abre);

function abre(e) {
    e.preventDefault();
    $nav.toggleClass('active');
}
// fixar header
$(window).scroll(fixar);

function fixar() {
    if ($(this).scrollTop() > 100) {
        $(".header").addClass('fixed');
    } else {
        $(".header").removeClass('fixed');
    }

}
// Dialog
let $abre_modal = $(".dialog-open");
let $fechar_modal = $(".dialog-close");
let $dialog = $(".dialog");
$abre_modal.click(modal);
$fechar_modal.click(fechar)

function modal(e) {
    e.preventDefault();
    let target = $(this).attr('href');
    $(".dialog").fadeIn('200', modal_conteudo(target));

}

function fechar() {

    $(".dialog-body").fadeOut('200', fechar_principal($dialog));

}

function modal_conteudo(href_elemento) {
    $(href_elemento).fadeIn('200');
}

function fechar_principal(fechar_dialog) {
    $(fechar_dialog).fadeOut('200');
}


//fim Dialog
//Carousel Principal
$('.owl-carousel').owlCarousel({
    items: 1,
    lazyLoad: true,
    loop: true,
    margin: 0,
    nav: true,
    navSpeed: 1000,
    navText: ['<img src ="images/chevron-esquerda.png">', '<img src ="images/chevron-direito.png">'],
    dots: true,
    dotsSpeed: 1000,
    autoplay: true,
    autoplaySpeed: 1000,
    responsiveRefreshRate: 10
});