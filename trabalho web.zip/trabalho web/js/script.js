let $menu = $(".nav-toggle");
let $nav = $(".nav");
let $navclose = $(".nav-close")
$menu.click(abre);
$navclose.click(abre);

function abre(e) {
    e.preventDefault();
    $nav.toggleClass('active');
}
// fixar header
$(window).scroll(fixar);

function fixar() {
    if ($(this).scrollTop() > 100) {
        $(".header").addClass('fixed');
    } else {
        $(".header").removeClass('fixed');
    }

}
//Carousel Principal
$('.owl-carousel').owlCarousel({
    items: 1,
    lazyLoad: true,
    loop: true,
    margin: 0,
    nav: true,
    navSpeed: 1000,
    navText: ['<img src ="images/chevron-esquerda.png">', '<img src ="images/chevron-direito.png">'],
    dots: true,
    dotsSpeed: 1000,
    autoplay: true,
    autoplaySpeed: 1000,
    responsiveRefreshRate: 10
});