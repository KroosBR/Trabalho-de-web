let $menu = $(".nav-toggle");
let $nav = $(".nav");
let $navclose = $(".nav-close")
$menu.click(abre);
$navclose.click(abre);

function abre(e) {
    e.preventDefault();
    $nav.toggleClass('active');
}