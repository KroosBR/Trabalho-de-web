<?php
$servidor = "localhost";
$usuario = "root";
$senha = "";
$dbname = "arthur";

$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);
?>
