<?php
session_start();
?>
<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
		<title>Cadastrar</title>
	</head>
	<body>
		<h1>Cadastrar Usuário</h1>
		<?php
		if(isset($_SESSION['msg'])){
			echo $_SESSION['msg'];
			unset($_SESSION['msg']);
		}
		?>
		<form method="POST" action="processa.php">
			<label>Nick: </label>
			<input type="text" name="nome" placeholder="Digite o nome de usuário"><br><br>
			<label>E-mail: </label>
			<input type="email" name="email" placeholder="Digite o seu e-mail"><br><br>
			<input type="submit" value="Cadastrar">
			<p>Já tenho conta</p>
			<a href="login.html">Login</a>
		</form>
	</body>
</html>
