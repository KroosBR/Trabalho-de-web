class Scene1 extends Phaser.Scene {
  constructor() {
    super('boot');
  }
  preload(){
    this.load.image('background','img/ceu.jpg');
    this.load.image('back','img/back.png');
    this.load.spritesheet('personagem','img/dude.png',{
      frameWidth:32,
      frameHeight:48
    });
    this.load.spritesheet('bum','img/bum.jpg',{
      frameWidth:32.25,
      frameHeigth:32.5
    });
    this.load.image('enemy','img/lixo.png');
  }
  create(){
    this.add.text(20,20,"Loading...");
    this.anims.create({
      key:'perso_a',
      frames: this.anims.generateFrameNumbers('personagem', { start: 6, end: 8 }),
      frameRate:10,
      repeat: -1
    });
    this.anims.create({
      key:'explosion',
      frames:this.anims.generateFrameNumbers('bum'),
      frameRate:120,
      repeat:0,
      hideOnComplete:true
    });
    this.scene.start('play');
  }
}
