var r;
class Scene2 extends Phaser.Scene {
  constructor() {
    super('play');
  }
  create(){
    this.score = 0;

    this.background = this.add.tileSprite(0,0,config.width,config.height,'background');
    this.background.setOrigin(0,0);
    this.back = this.add.tileSprite(0,100,config.width,74,'back');
    this.back.setOrigin(0,0);
    this.perso = this.physics.add.sprite(0,101,'personagem');
    this.perso.setOrigin(0,0);
    this.perso.setScale(1);
    this.carro = this.physics.add.image(290,150,'enemy');
    this.carro.rotateX = true;
    this.carro.setScale(0.06);
    this.carro.body.setAllowGravity(false);
    this.perso.setCollideWorldBounds(true);
    this.perso.play('perso_a');
    this.perso.setInteractive();
    this.tet = this.add.text(20,20,"SCORE: 0");
    this.input.on('gameobjectdown',this.cabum,this);
    this.teclado = this.input.keyboard.createCursorKeys();
    //this.scene.switch('fim');
    this.space = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);
  }
  /*movecara(cara,vel){
    cara.x += vel;
    if(cara.x > config.width){
      this.reset(cara);
    }
  }
  reset(cara){
    cara.x=-71;
  }*/
  cabum(pointer,coisa){
    coisa.setTexture('bum');
    coisa.play('explosion');
  }
  moveini(ini,f){
      ini.x -= 3.4 ;
    if(ini.x < 0){
      ini.x = 290;
      this.score += 25;
      this.tet.setText("SCORE:"+this.score);
      //console.log(this.score);
    }
  }

  update(){
    this.physics.add.collider(this.carro,this.perso,function(prin,car){
      car.setTexture('bum');
      car.play('explosion');
      prin.destroy();
      car.y = 107;
      car.destroy();
      this.scene.switch('fim');
    });
    //this.movecara(this.perso,2);

    this.carro.angle -= 30;
    this.moveini(this.carro);
    this.background.tilePositionX += 0.2;
    this.back.tilePositionX += 6;
    this.movePLayerManager();
    if(Phaser.Input.Keyboard.JustDown(this.space)){
     if(this.perso.y >= 95){
      this.perso.setVelocityY(-200);
    }
    }
    }
    movePLayerManager(){
    }
}
