class Scene3 extends Phaser.Scene {
  constructor() {
    super('fim');
  }
  create(){
    this.add.text(20,20,'Morreu');
  }

}
