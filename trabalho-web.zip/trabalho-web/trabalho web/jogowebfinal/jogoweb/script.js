var config = {
  width: 290,
  height: 174,
  scene: [Scene1,Scene2,Scene3],
  physics: {
        default: 'arcade',
        arcade: {
            gravity: { y: 300 },
            debug: false
        }
    },
}
var vel = {
  playerSpeed: 200,
}
var game = new Phaser.Game(config);
