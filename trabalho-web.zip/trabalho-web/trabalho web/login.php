<?php
$entrar = $_POST['entrar'];
$login = $_POST['login'];
$email = $_POST['email'];
$connect = mysqli_connect('localhost','root','','arthur');
  if (isset($entrar)) {
      mysqli_query($connect,"SELECT * FROM usuarios WHERE login = '$login' AND email = '$email'")
        or die;
      if (mysqli_num_rows($connect)<=0){
        $_SESSION['msg'] = "<p style='color:green;'>Login não concluido</p>";

        die();
      }else{
        $_SESSION['msg'] = "<p style='color:green;'>Login concluido com sucesso</p>";
      	header("Location: index.php");
      }
  }
?>
